const express = require("express");

const {
  createStudent,
  getStudents,
  getDeletedStudents,
  getStudentById,
  updateStudent,
  deleteStudent,
  restoreStudent
} = require("../controllers/studentController");

const {
  protect,
  authorize
} = require("../middlewares/authMiddleware");

const schoolScope = require("../middlewares/schoolScopeMiddleware");
const validateObjectId = require("../middlewares/validateObjectId");

const router = express.Router();

/* =========================
   Student Routes
========================= */

// Create student
// super_admin: body سے schoolId دے سکتا ہے
// principal: اپنے school میں student create کرے گا
router.post(
  "/",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  createStudent
);

// Get all active/non-deleted students
// super_admin: تمام schools یا query schoolId کے حساب سے دیکھ سکتا ہے
// principal/teacher/accountant: صرف اپنے school کے students دیکھ سکتے ہیں
router.get(
  "/",
  protect,
  authorize("super_admin", "principal", "teacher", "accountant"),
  schoolScope,
  getStudents
);

// Get soft deleted students
// super_admin/principal only
router.get(
  "/deleted/list",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  getDeletedStudents
);

// Restore soft deleted student
// super_admin/principal only
router.patch(
  "/:id/restore",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  restoreStudent
);

// Get single student by ID
// school restricted
router.get(
  "/:id",
  protect,
  authorize("super_admin", "principal", "teacher", "accountant"),
  schoolScope,
  validateObjectId("id"),
  getStudentById
);

// Update student
// super_admin/principal only
// school restricted
router.put(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  updateStudent
);

// Soft delete student
// super_admin/principal only
// school restricted
router.delete(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  deleteStudent
);

module.exports = router;