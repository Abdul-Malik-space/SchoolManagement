const express = require("express");

const {
  createTeacher,
  getTeachers,
  getDeletedTeachers,
  getTeacherById,
  updateTeacher,
  deleteTeacher,
  restoreTeacher
} = require("../controllers/teacherController");

const {
  protect,
  authorize
} = require("../middlewares/authMiddleware");

const schoolScope = require("../middlewares/schoolScopeMiddleware");
const validateObjectId = require("../middlewares/validateObjectId");

const router = express.Router();

/* =========================
   Teacher Routes
========================= */

// Create teacher
// super_admin: body سے schoolId دے سکتا ہے
// principal: اپنے school میں teacher create کرے گا
router.post(
  "/",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  createTeacher
);

// Get all active/non-deleted teachers
router.get(
  "/",
  protect,
  authorize("super_admin", "principal", "teacher", "accountant"),
  schoolScope,
  getTeachers
);

// Get soft deleted teachers
router.get(
  "/deleted/list",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  getDeletedTeachers
);

// Restore soft deleted teacher
router.patch(
  "/:id/restore",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  restoreTeacher
);

// Get single teacher by ID
router.get(
  "/:id",
  protect,
  authorize("super_admin", "principal", "teacher", "accountant"),
  schoolScope,
  validateObjectId("id"),
  getTeacherById
);

// Update teacher
router.put(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  updateTeacher
);

// Soft delete teacher
router.delete(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  deleteTeacher
);

module.exports = router;