const express = require("express");

const {
  collectFee,
  addPayment,
  getFeeCollections,
  getFeeCollectionById,
  deleteFeeCollection
} = require("../controllers/feeCollectionController");

const {
  protect,
  authorize
} = require("../middlewares/authMiddleware");

const schoolScope = require("../middlewares/schoolScopeMiddleware");
const validateObjectId = require("../middlewares/validateObjectId");

const router = express.Router();

/* =========================
   Fee Collection Routes
========================= */

// Create fee collection
// super_admin: allowed for any school through valid scoped records
// principal/accountant: only their own school
router.post(
  "/",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  collectFee
);

// Get all fee collections
// super_admin: all schools or query schoolId
// principal/accountant: only their own school
router.get(
  "/",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  getFeeCollections
);

// Add payment to fee collection
// New recommended route
// Example:
// PATCH /api/fee-collections/:id/payment
router.patch(
  "/:id/payment",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  validateObjectId("id"),
  addPayment
);

// Add payment to fee collection
// Old route kept for backward compatibility
// Example:
// PUT /api/fee-collections/:id/pay
router.put(
  "/:id/pay",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  validateObjectId("id"),
  addPayment
);

// Get single fee collection by ID
// school restricted
// Important: keep this after /:id/payment and /:id/pay
router.get(
  "/:id",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  validateObjectId("id"),
  getFeeCollectionById
);

// Delete fee collection
// super_admin/principal only
// school restricted
router.delete(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  deleteFeeCollection
);

module.exports = router;