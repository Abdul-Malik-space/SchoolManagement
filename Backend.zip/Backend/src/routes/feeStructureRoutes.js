const express = require("express");

const {
  createFeeStructure,
  getFeeStructures,
  getFeeStructureById,
  updateFeeStructure,
  deleteFeeStructure
} = require("../controllers/feeStructureController");

const {
  protect,
  authorize
} = require("../middlewares/authMiddleware");

const schoolScope = require("../middlewares/schoolScopeMiddleware");
const validateObjectId = require("../middlewares/validateObjectId");

const router = express.Router();

/* =========================
   Fee Structure Routes
========================= */

// Create fee structure
// super_admin: body سے schoolId دے سکتا ہے
// principal/accountant: اپنے school میں fee structure create کریں گے
router.post(
  "/",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  createFeeStructure
);

// Get all fee structures
// super_admin: تمام schools یا query schoolId کے حساب سے دیکھ سکتا ہے
// principal/accountant: صرف اپنے school کے fee structures دیکھ سکتے ہیں
router.get(
  "/",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  getFeeStructures
);

// Get single fee structure by ID
// school restricted
router.get(
  "/:id",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  validateObjectId("id"),
  getFeeStructureById
);

// Update fee structure
// super_admin/principal/accountant
// school restricted
router.put(
  "/:id",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  validateObjectId("id"),
  updateFeeStructure
);

// Delete fee structure
// super_admin/principal only
// school restricted
router.delete(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  deleteFeeStructure
);

module.exports = router;