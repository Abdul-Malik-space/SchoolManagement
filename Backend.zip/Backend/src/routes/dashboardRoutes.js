const express = require("express");

const {
  getDashboardSummary
} = require("../controllers/dashboardController");

const {
  protect,
  authorize
} = require("../middlewares/authMiddleware");

const schoolScope = require("../middlewares/schoolScopeMiddleware");

const router = express.Router();

/* =========================
   Dashboard Routes
========================= */

// Dashboard summary
// super_admin: all schools یا query schoolId کے حساب سے summary دیکھ سکتا ہے
// principal/accountant: صرف اپنے school کی summary دیکھ سکتے ہیں
router.get(
  "/summary",
  protect,
  authorize("super_admin", "principal", "accountant"),
  schoolScope,
  getDashboardSummary
);

module.exports = router;