const express = require("express");

const {
  getAuditLogs,
  getAuditLogById,
  deleteAuditLog
} = require("../controllers/auditLogController");

const {
  protect,
  authorize
} = require("../middlewares/authMiddleware");

const schoolScope = require("../middlewares/schoolScopeMiddleware");
const validateObjectId = require("../middlewares/validateObjectId");

const router = express.Router();

/* =========================
   Audit Log Routes
========================= */

// Get audit logs
// super_admin: all schools logs or query schoolId
// principal: only own school logs
router.get(
  "/",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  getAuditLogs
);

// Get single audit log by ID
// school restricted
router.get(
  "/:id",
  protect,
  authorize("super_admin", "principal"),
  schoolScope,
  validateObjectId("id"),
  getAuditLogById
);

// Delete audit log
// only super_admin
router.delete(
  "/:id",
  protect,
  authorize("super_admin"),
  schoolScope,
  validateObjectId("id"),
  deleteAuditLog
);

module.exports = router;