const Teacher = require("../models/Teacher");
const School = require("../models/School");

const {
  getPaginationOptions,
  buildPagination
} = require("../utils/pagination");

const {
  createAuditLog
} = require("../utils/auditLogHelper");

const generateEmployeeId = () => {
  const year = new Date().getFullYear();
  const randomNumber = Math.floor(100000 + Math.random() * 900000);
  return `TCH-${year}-${randomNumber}`;
};

const generateUniqueEmployeeId = async (schoolId) => {
  let employeeId;
  let exists = true;
  let attempts = 0;

  while (exists && attempts < 10) {
    employeeId = generateEmployeeId();

    exists = await Teacher.findOne({
      schoolId,
      employeeId
    }).select("_id");

    attempts += 1;
  }

  if (exists) {
    throw new Error("Failed to generate unique employee ID");
  }

  return employeeId;
};

const isSuperAdmin = (req) => {
  return req.user && req.user.role === "super_admin";
};

const getUserSchoolId = (req) => {
  const schoolId = req.user && req.user.schoolId;

  if (!schoolId) {
    return null;
  }

  if (schoolId._id) {
    return schoolId._id.toString();
  }

  return schoolId.toString();
};

const getSchoolFilter = (req) => {
  if (isSuperAdmin(req)) {
    return {};
  }

  if (req.schoolFilter && Object.keys(req.schoolFilter).length > 0) {
    return { ...req.schoolFilter };
  }

  const userSchoolId = getUserSchoolId(req);

  if (!userSchoolId) {
    return { schoolId: null };
  }

  return { schoolId: userSchoolId };
};

const getCreateSchoolId = (req) => {
  if (isSuperAdmin(req)) {
    return req.body.schoolId;
  }

  return getUserSchoolId(req);
};

const getPlainData = (document) => {
  if (!document) {
    return null;
  }

  if (typeof document.toObject === "function") {
    return document.toObject();
  }

  return document;
};

const buildTeacherFilter = (req, deletedStatus = false) => {
  const filter = {
    ...getSchoolFilter(req)
  };

  if (deletedStatus === true) {
    filter.isDeleted = true;
  } else {
    filter.isDeleted = { $ne: true };
  }

  if (isSuperAdmin(req) && req.query.schoolId) {
    filter.schoolId = req.query.schoolId;
  }

  if (req.query.status) {
    filter.status = req.query.status;
  }

  if (req.query.gender) {
    filter.gender = req.query.gender;
  }

  if (req.query.subject) {
    filter.subjects = new RegExp(req.query.subject, "i");
  }

  if (req.query.search) {
    const searchRegex = new RegExp(req.query.search, "i");

    filter.$or = [
      { name: searchRegex },
      { fatherName: searchRegex },
      { email: searchRegex },
      { phone: searchRegex },
      { cnic: searchRegex },
      { qualification: searchRegex },
      { employeeId: searchRegex },
      { subjects: searchRegex }
    ];
  }

  return filter;
};

exports.createTeacher = async (req, res) => {
  try {
    const {
      name,
      fatherName,
      email,
      phone,
      cnic,
      gender,
      dateOfBirth,
      address,
      qualification,
      subjects,
      salary,
      joiningDate,
      teacherPhoto
    } = req.body;

    const schoolId = getCreateSchoolId(req);

    if (!schoolId || !name || !phone || !gender || !qualification) {
      return res.status(400).json({
        success: false,
        message: "School ID, name, phone, gender and qualification are required"
      });
    }

    const school = await School.findById(schoolId);

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found"
      });
    }

    const employeeId = await generateUniqueEmployeeId(schoolId);

    const teacher = await Teacher.create({
      schoolId,
      employeeId,
      name,
      fatherName,
      email,
      phone,
      cnic,
      gender,
      dateOfBirth,
      address,
      qualification,
      subjects,
      salary,
      joiningDate,
      teacherPhoto,
      createdBy: req.user._id,
      isDeleted: false,
      deletedAt: null,
      deletedBy: null
    });

    await createAuditLog({
      req,
      schoolId: teacher.schoolId,
      action: "CREATE",
      module: "TEACHER",
      recordId: teacher._id,
      recordModel: "Teacher",
      description: `Teacher created successfully: ${teacher.name}`,
      oldData: null,
      newData: getPlainData(teacher),
      status: "success",
      metadata: {
        employeeId: teacher.employeeId,
        phone: teacher.phone,
        email: teacher.email || "",
        subjects: teacher.subjects || []
      }
    });

    res.status(201).json({
      success: true,
      message: "Teacher created successfully",
      teacher
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to create teacher",
      error: error.message
    });
  }
};

exports.getTeachers = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationOptions(req.query);

    const filter = buildTeacherFilter(req, false);

    const total = await Teacher.countDocuments(filter);

    const teachers = await Teacher.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      count: teachers.length,
      pagination: buildPagination({ total, page, limit }),
      teachers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch teachers",
      error: error.message
    });
  }
};

exports.getDeletedTeachers = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationOptions(req.query);

    const filter = buildTeacherFilter(req, true);

    const total = await Teacher.countDocuments(filter);

    const teachers = await Teacher.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role")
      .populate("deletedBy", "name email role")
      .sort({ deletedAt: -1, updatedAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      count: teachers.length,
      pagination: buildPagination({ total, page, limit }),
      teachers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch deleted teachers",
      error: error.message
    });
  }
};

exports.getTeacherById = async (req, res) => {
  try {
    const filter = {
      _id: req.params.id,
      ...getSchoolFilter(req),
      isDeleted: { $ne: true }
    };

    const teacher = await Teacher.findOne(filter)
      .populate("schoolId", "schoolName type")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role");

    if (!teacher) {
      return res.status(404).json({
        success: false,
        message: "Teacher not found"
      });
    }

    res.status(200).json({
      success: true,
      teacher
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch teacher",
      error: error.message
    });
  }
};

exports.updateTeacher = async (req, res) => {
  try {
    const filter = {
      _id: req.params.id,
      ...getSchoolFilter(req),
      isDeleted: { $ne: true }
    };

    const existingTeacher = await Teacher.findOne(filter);

    if (!existingTeacher) {
      return res.status(404).json({
        success: false,
        message: "Teacher not found"
      });
    }

    const oldTeacherData = getPlainData(existingTeacher);

    const updateData = { ...req.body };

    delete updateData.schoolId;
    delete updateData.employeeId;
    delete updateData.createdBy;
    delete updateData.updatedBy;
    delete updateData.isDeleted;
    delete updateData.deletedAt;
    delete updateData.deletedBy;

    updateData.updatedBy = req.user._id;

    const teacher = await Teacher.findOneAndUpdate(
      filter,
      updateData,
      {
        returnDocument: "after",
        runValidators: true
      }
    )
      .populate("schoolId", "schoolName type")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role");

    await createAuditLog({
      req,
      schoolId: existingTeacher.schoolId,
      action: "UPDATE",
      module: "TEACHER",
      recordId: teacher._id,
      recordModel: "Teacher",
      description: `Teacher updated successfully: ${teacher.name}`,
      oldData: oldTeacherData,
      newData: getPlainData(teacher),
      status: "success",
      metadata: {
        employeeId: teacher.employeeId,
        updatedFields: Object.keys(updateData).filter((field) => field !== "updatedBy")
      }
    });

    res.status(200).json({
      success: true,
      message: "Teacher updated successfully",
      teacher
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to update teacher",
      error: error.message
    });
  }
};

exports.deleteTeacher = async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);

    if (!teacher) {
      return res.status(404).json({
        success: false,
        message: "Teacher not found"
      });
    }

    if (teacher.isDeleted === true) {
      return res.status(400).json({
        success: false,
        message: "Teacher is already deleted"
      });
    }

    if (!isSuperAdmin(req)) {
      const userSchoolId = getUserSchoolId(req);

      if (!userSchoolId) {
        return res.status(403).json({
          success: false,
          message: "School is not assigned to this user"
        });
      }

      if (teacher.schoolId.toString() !== userSchoolId.toString()) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to delete another school's teacher"
        });
      }
    }

    const oldTeacherData = getPlainData(teacher);

    teacher.isDeleted = true;
    teacher.deletedAt = new Date();
    teacher.deletedBy = req.user._id;
    teacher.updatedBy = req.user._id;

    await teacher.save();

    await createAuditLog({
      req,
      schoolId: teacher.schoolId,
      action: "DELETE",
      module: "TEACHER",
      recordId: teacher._id,
      recordModel: "Teacher",
      description: `Teacher soft deleted successfully: ${teacher.name}`,
      oldData: oldTeacherData,
      newData: getPlainData(teacher),
      status: "success",
      metadata: {
        employeeId: teacher.employeeId,
        phone: teacher.phone,
        email: teacher.email || "",
        deletedAt: teacher.deletedAt,
        softDelete: true
      }
    });

    res.status(200).json({
      success: true,
      message: "Teacher deleted successfully",
      teacher
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete teacher",
      error: error.message
    });
  }
};

exports.restoreTeacher = async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);

    if (!teacher) {
      return res.status(404).json({
        success: false,
        message: "Teacher not found"
      });
    }

    if (teacher.isDeleted !== true) {
      return res.status(400).json({
        success: false,
        message: "Teacher is not deleted"
      });
    }

    if (!isSuperAdmin(req)) {
      const userSchoolId = getUserSchoolId(req);

      if (!userSchoolId) {
        return res.status(403).json({
          success: false,
          message: "School is not assigned to this user"
        });
      }

      if (teacher.schoolId.toString() !== userSchoolId.toString()) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to restore another school's teacher"
        });
      }
    }

    const oldTeacherData = getPlainData(teacher);

    teacher.isDeleted = false;
    teacher.deletedAt = null;
    teacher.deletedBy = null;
    teacher.updatedBy = req.user._id;

    await teacher.save();

    await teacher.populate([
      { path: "schoolId", select: "schoolName type" },
      { path: "createdBy", select: "name email role" },
      { path: "updatedBy", select: "name email role" }
    ]);

    await createAuditLog({
      req,
      schoolId: teacher.schoolId,
      action: "UPDATE",
      module: "TEACHER",
      recordId: teacher._id,
      recordModel: "Teacher",
      description: `Teacher restored successfully: ${teacher.name}`,
      oldData: oldTeacherData,
      newData: getPlainData(teacher),
      status: "success",
      metadata: {
        employeeId: teacher.employeeId,
        phone: teacher.phone,
        email: teacher.email || "",
        restored: true
      }
    });

    res.status(200).json({
      success: true,
      message: "Teacher restored successfully",
      teacher
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to restore teacher",
      error: error.message
    });
  }
};