const mongoose = require("mongoose");

const FeeCollection = require("../models/FeeCollection");
const FeeStructure = require("../models/FeeStructure");
const Student = require("../models/Student");

const {
  getPaginationOptions,
  buildPagination
} = require("../utils/pagination");

const { createAuditLog } = require("../utils/auditLogHelper");

const isSuperAdmin = (req) => {
  return req.user && req.user.role === "super_admin";
};

const getUserSchoolId = (req) => {
  const schoolId = req.user && req.user.schoolId;

  if (!schoolId) {
    return null;
  }

  if (schoolId._id) {
    return schoolId._id.toString();
  }

  return schoolId.toString();
};

const getSchoolFilter = (req) => {
  if (isSuperAdmin(req)) {
    return {};
  }

  if (req.schoolFilter && Object.keys(req.schoolFilter).length > 0) {
    return { ...req.schoolFilter };
  }

  const userSchoolId = getUserSchoolId(req);

  if (!userSchoolId) {
    return { schoolId: null };
  }

  return { schoolId: userSchoolId };
};

const getScopedFilter = (req, extraFilter = {}) => {
  return {
    ...getSchoolFilter(req),
    ...extraFilter
  };
};

const getPlainData = (document) => {
  if (!document) {
    return null;
  }

  if (typeof document.toObject === "function") {
    return document.toObject();
  }

  return document;
};

const isValidObjectId = (id) => {
  return id && mongoose.Types.ObjectId.isValid(id);
};

const isValidFeeMonth = (feeMonth) => {
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(feeMonth);
};

const toNumber = (value, defaultValue = 0) => {
  if (value === undefined || value === null || value === "") {
    return defaultValue;
  }

  const numberValue = Number(value);

  if (!Number.isFinite(numberValue)) {
    return null;
  }

  return numberValue;
};

const handleControllerError = (res, error, defaultMessage) => {
  if (error.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      message: Object.values(error.errors)
        .map((item) => item.message)
        .join(", ")
    });
  }

  if (error.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: "Invalid ID format"
    });
  }

  if (error.code === 11000) {
    return res.status(400).json({
      success: false,
      message: "Fee record already exists for this student in this month"
    });
  }

  return res.status(500).json({
    success: false,
    message: defaultMessage,
    error: error.message
  });
};

const generateInvoiceNumber = () => {
  const year = new Date().getFullYear();
  const randomNumber = Math.floor(100000 + Math.random() * 900000);
  return `INV-${year}-${randomNumber}`;
};

const generateUniqueInvoiceNumber = async () => {
  let invoiceNumber;
  let exists = true;
  let attempts = 0;

  while (exists && attempts < 10) {
    invoiceNumber = generateInvoiceNumber();

    exists = await FeeCollection.findOne({
      invoiceNumber
    }).select("_id");

    attempts += 1;
  }

  if (exists) {
    throw new Error("Failed to generate unique invoice number");
  }

  return invoiceNumber;
};

const calculateTotalAmount = (feeStructure) => {
  return (
    Number(feeStructure.monthlyFee || 0) +
    Number(feeStructure.admissionFee || 0) +
    Number(feeStructure.examFee || 0) +
    Number(feeStructure.transportFee || 0) +
    Number(feeStructure.otherFee || 0)
  );
};

exports.collectFee = async (req, res) => {
  try {
    const {
      studentId,
      feeStructureId,
      feeMonth,
      sessionYear,
      discount,
      fine,
      paidAmount,
      paymentMethod,
      remarks
    } = req.body;

    if (!studentId || !feeStructureId || !feeMonth || !sessionYear) {
      return res.status(400).json({
        success: false,
        message: "Student ID, fee structure ID, fee month and session year are required"
      });
    }

    if (!isValidObjectId(studentId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid student ID format"
      });
    }

    if (!isValidObjectId(feeStructureId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid fee structure ID format"
      });
    }

    if (!isValidFeeMonth(feeMonth)) {
      return res.status(400).json({
        success: false,
        message: "Invalid fee month format. Use YYYY-MM"
      });
    }

    const finalDiscount = toNumber(discount, 0);
    const finalFine = toNumber(fine, 0);
    const finalPaidAmount = toNumber(paidAmount, 0);

    if (finalDiscount === null) {
      return res.status(400).json({
        success: false,
        message: "Discount must be a valid number"
      });
    }

    if (finalFine === null) {
      return res.status(400).json({
        success: false,
        message: "Fine must be a valid number"
      });
    }

    if (finalPaidAmount === null) {
      return res.status(400).json({
        success: false,
        message: "Paid amount must be a valid number"
      });
    }

    if (finalDiscount < 0) {
      return res.status(400).json({
        success: false,
        message: "Discount cannot be negative"
      });
    }

    if (finalFine < 0) {
      return res.status(400).json({
        success: false,
        message: "Fine cannot be negative"
      });
    }

    if (finalPaidAmount < 0) {
      return res.status(400).json({
        success: false,
        message: "Paid amount cannot be negative"
      });
    }

    const student = await Student.findOne(
      getScopedFilter(req, { _id: studentId })
    );

    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found or not allowed"
      });
    }

    if (student.status && student.status !== "active") {
      return res.status(400).json({
        success: false,
        message: "Fee can only be collected for active students"
      });
    }

    const feeStructure = await FeeStructure.findOne(
      getScopedFilter(req, { _id: feeStructureId })
    );

    if (!feeStructure) {
      return res.status(404).json({
        success: false,
        message: "Fee structure not found or not allowed"
      });
    }

    if (feeStructure.isActive === false) {
      return res.status(400).json({
        success: false,
        message: "Fee structure is inactive"
      });
    }

    if (student.schoolId.toString() !== feeStructure.schoolId.toString()) {
      return res.status(400).json({
        success: false,
        message: "Student and fee structure do not belong to the same school"
      });
    }

    if (student.classId.toString() !== feeStructure.classId.toString()) {
      return res.status(400).json({
        success: false,
        message: "Student and fee structure do not belong to the same class"
      });
    }

    if (feeStructure.sessionYear !== sessionYear) {
      return res.status(400).json({
        success: false,
        message: "Fee structure session year does not match"
      });
    }

    const existingFee = await FeeCollection.findOne(
      getScopedFilter(req, {
        studentId,
        feeMonth,
        sessionYear
      })
    );

    if (existingFee) {
      return res.status(400).json({
        success: false,
        message: "Fee record already exists for this student in this month"
      });
    }

    const totalAmount = calculateTotalAmount(feeStructure);
    const payableAmount = totalAmount + finalFine - finalDiscount;

    if (payableAmount < 0) {
      return res.status(400).json({
        success: false,
        message: "Payable amount cannot be negative"
      });
    }

    if (finalPaidAmount > payableAmount) {
      return res.status(400).json({
        success: false,
        message: "Paid amount cannot be greater than payable amount"
      });
    }

    const payments = [];

    if (finalPaidAmount > 0) {
      payments.push({
        amount: finalPaidAmount,
        paymentMethod: paymentMethod || "cash",
        remarks: remarks || "",
        receivedBy: req.user._id
      });
    }

    const invoiceNumber = await generateUniqueInvoiceNumber();

    const feeCollection = await FeeCollection.create({
      schoolId: student.schoolId,
      studentId,
      classId: student.classId,
      feeStructureId,
      feeMonth,
      sessionYear,
      invoiceNumber,
      monthlyFee: feeStructure.monthlyFee,
      admissionFee: feeStructure.admissionFee,
      examFee: feeStructure.examFee,
      transportFee: feeStructure.transportFee,
      otherFee: feeStructure.otherFee,
      discount: finalDiscount,
      fine: finalFine,
      payments,
      createdBy: req.user._id
    });

    await createAuditLog({
      req,
      schoolId: feeCollection.schoolId,
      action: "CREATE",
      module: "FEE_COLLECTION",
      recordId: feeCollection._id,
      recordModel: "FeeCollection",
      description: `Fee collection created for student ${student.name} against invoice ${invoiceNumber}`,
      oldData: null,
      newData: getPlainData(feeCollection),
      status: "success",
      metadata: {
        invoiceNumber,
        studentId,
        classId: student.classId,
        feeStructureId,
        feeMonth,
        sessionYear,
        totalAmount,
        payableAmount,
        paidAmount: finalPaidAmount,
        paymentStatus: feeCollection.paymentStatus
      }
    });

    await feeCollection.populate([
      { path: "schoolId", select: "schoolName type" },
      { path: "studentId", select: "name fatherName admissionNumber sectionName" },
      { path: "classId", select: "className numericOrder" },
      { path: "feeStructureId", select: "title sessionYear" },
      { path: "payments.receivedBy", select: "name role" }
    ]);

    res.status(201).json({
      success: true,
      message: "Fee collected successfully",
      feeCollection
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to collect fee"
    );
  }
};

exports.addPayment = async (req, res) => {
  try {
    const { amount, paymentMethod, remarks } = req.body;

    const paymentAmount = toNumber(amount, null);

    if (paymentAmount === null || paymentAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: "Valid payment amount is required"
      });
    }

    const feeCollection = await FeeCollection.findOne(
      getScopedFilter(req, { _id: req.params.id })
    );

    if (!feeCollection) {
      return res.status(404).json({
        success: false,
        message: "Fee collection record not found or not allowed"
      });
    }

    const oldData = getPlainData(feeCollection);

    const currentPaidAmount = feeCollection.payments.reduce((sum, payment) => {
      return sum + Number(payment.amount || 0);
    }, 0);

    const currentBalanceAmount =
      Number(feeCollection.payableAmount || 0) - currentPaidAmount;

    if (currentBalanceAmount <= 0 || feeCollection.paymentStatus === "paid") {
      return res.status(400).json({
        success: false,
        message: "This fee is already fully paid"
      });
    }

    if (paymentAmount > currentBalanceAmount) {
      return res.status(400).json({
        success: false,
        message: "Payment amount cannot be greater than balance amount"
      });
    }

    feeCollection.payments.push({
      amount: paymentAmount,
      paymentMethod: paymentMethod || "cash",
      remarks: remarks || "",
      receivedBy: req.user._id
    });

    await feeCollection.save();

    const newPaidAmount = feeCollection.payments.reduce((sum, payment) => {
      return sum + Number(payment.amount || 0);
    }, 0);

    const newBalanceAmount =
      Number(feeCollection.payableAmount || 0) - newPaidAmount;

    await createAuditLog({
      req,
      schoolId: feeCollection.schoolId,
      action: "PAYMENT",
      module: "FEE_COLLECTION",
      recordId: feeCollection._id,
      recordModel: "FeeCollection",
      description: `Payment added against invoice ${feeCollection.invoiceNumber}`,
      oldData,
      newData: getPlainData(feeCollection),
      status: "success",
      metadata: {
        invoiceNumber: feeCollection.invoiceNumber,
        paymentAmount,
        paymentMethod: paymentMethod || "cash",
        previousPaidAmount: currentPaidAmount,
        newPaidAmount,
        previousBalanceAmount: currentBalanceAmount,
        newBalanceAmount,
        previousPaymentStatus: oldData.paymentStatus,
        newPaymentStatus: feeCollection.paymentStatus
      }
    });

    await feeCollection.populate([
      { path: "schoolId", select: "schoolName type" },
      { path: "studentId", select: "name fatherName admissionNumber sectionName" },
      { path: "classId", select: "className numericOrder" },
      { path: "feeStructureId", select: "title sessionYear" },
      { path: "payments.receivedBy", select: "name role" }
    ]);

    res.status(200).json({
      success: true,
      message: "Payment added successfully",
      feeCollection
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to add payment"
    );
  }
};

exports.getFeeCollections = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationOptions(req.query);

    const filter = getSchoolFilter(req);

    if (isSuperAdmin(req) && req.query.schoolId) {
      if (!isValidObjectId(req.query.schoolId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid school ID format"
        });
      }

      filter.schoolId = req.query.schoolId;
    }

    if (req.query.classId) {
      if (!isValidObjectId(req.query.classId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid class ID format"
        });
      }

      filter.classId = req.query.classId;
    }

    if (req.query.studentId) {
      if (!isValidObjectId(req.query.studentId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid student ID format"
        });
      }

      filter.studentId = req.query.studentId;
    }

    if (req.query.feeStructureId) {
      if (!isValidObjectId(req.query.feeStructureId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid fee structure ID format"
        });
      }

      filter.feeStructureId = req.query.feeStructureId;
    }

    if (req.query.feeMonth) {
      if (!isValidFeeMonth(req.query.feeMonth)) {
        return res.status(400).json({
          success: false,
          message: "Invalid fee month format. Use YYYY-MM"
        });
      }

      filter.feeMonth = req.query.feeMonth;
    }

    if (req.query.sessionYear) {
      filter.sessionYear = req.query.sessionYear;
    }

    if (req.query.paymentStatus) {
      if (!["unpaid", "partial", "paid"].includes(req.query.paymentStatus)) {
        return res.status(400).json({
          success: false,
          message: "Invalid payment status"
        });
      }

      filter.paymentStatus = req.query.paymentStatus;
    }

    if (req.query.search) {
      const searchRegex = new RegExp(req.query.search, "i");

      const studentFilter = getSchoolFilter(req);

      if (isSuperAdmin(req) && req.query.schoolId) {
        studentFilter.schoolId = req.query.schoolId;
      }

      if (req.query.classId) {
        studentFilter.classId = req.query.classId;
      }

      const matchingStudents = await Student.find({
        ...studentFilter,
        $or: [
          { name: searchRegex },
          { fatherName: searchRegex },
          { admissionNumber: searchRegex }
        ]
      }).select("_id");

      const studentIds = matchingStudents.map((student) => student._id);

      filter.$or = [
        { invoiceNumber: searchRegex },
        { studentId: { $in: studentIds } }
      ];
    }

    const total = await FeeCollection.countDocuments(filter);

    const feeCollections = await FeeCollection.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("studentId", "name fatherName admissionNumber sectionName")
      .populate("classId", "className numericOrder")
      .populate("feeStructureId", "title sessionYear")
      .populate("payments.receivedBy", "name role")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      count: feeCollections.length,
      pagination: buildPagination({ total, page, limit }),
      feeCollections
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to fetch fee collections"
    );
  }
};

exports.getFeeCollectionById = async (req, res) => {
  try {
    const feeCollection = await FeeCollection.findOne(
      getScopedFilter(req, { _id: req.params.id })
    )
      .populate("schoolId", "schoolName type")
      .populate("studentId", "name fatherName admissionNumber sectionName")
      .populate("classId", "className numericOrder")
      .populate("feeStructureId", "title sessionYear")
      .populate("payments.receivedBy", "name role");

    if (!feeCollection) {
      return res.status(404).json({
        success: false,
        message: "Fee collection record not found or not allowed"
      });
    }

    res.status(200).json({
      success: true,
      feeCollection
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to fetch fee collection"
    );
  }
};

exports.deleteFeeCollection = async (req, res) => {
  try {
    const feeCollection = await FeeCollection.findOne(
      getScopedFilter(req, { _id: req.params.id })
    );

    if (!feeCollection) {
      return res.status(404).json({
        success: false,
        message: "Fee collection record not found or not allowed"
      });
    }

    const oldData = getPlainData(feeCollection);

    await feeCollection.deleteOne();

    await createAuditLog({
      req,
      schoolId: feeCollection.schoolId,
      action: "DELETE",
      module: "FEE_COLLECTION",
      recordId: feeCollection._id,
      recordModel: "FeeCollection",
      description: `Fee collection deleted for invoice ${feeCollection.invoiceNumber}`,
      oldData,
      newData: null,
      status: "success",
      metadata: {
        invoiceNumber: feeCollection.invoiceNumber,
        studentId: feeCollection.studentId,
        classId: feeCollection.classId,
        feeMonth: feeCollection.feeMonth,
        sessionYear: feeCollection.sessionYear,
        payableAmount: feeCollection.payableAmount,
        paymentStatus: feeCollection.paymentStatus
      }
    });

    res.status(200).json({
      success: true,
      message: "Fee collection deleted successfully"
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to delete fee collection"
    );
  }
};