const mongoose = require("mongoose");

const FeeStructure = require("../models/FeeStructure");
const School = require("../models/School");
const Class = require("../models/Class");

const {
  createAuditLog
} = require("../utils/auditLogHelper");

const isSuperAdmin = (req) => {
  return req.user && req.user.role === "super_admin";
};

const getUserSchoolId = (req) => {
  const schoolId = req.user && req.user.schoolId;

  if (!schoolId) {
    return null;
  }

  if (schoolId._id) {
    return schoolId._id.toString();
  }

  return schoolId.toString();
};

const getSchoolFilter = (req) => {
  if (isSuperAdmin(req)) {
    return {};
  }

  if (req.schoolFilter && Object.keys(req.schoolFilter).length > 0) {
    return { ...req.schoolFilter };
  }

  const userSchoolId = getUserSchoolId(req);

  if (!userSchoolId) {
    return { schoolId: null };
  }

  return { schoolId: userSchoolId };
};

const getCreateSchoolId = (req) => {
  if (isSuperAdmin(req)) {
    return req.body.schoolId;
  }

  return getUserSchoolId(req);
};

const getScopedFilter = (req, extraFilter = {}) => {
  return {
    ...getSchoolFilter(req),
    ...extraFilter
  };
};

const isValidObjectId = (id) => {
  return mongoose.Types.ObjectId.isValid(id);
};

const calculateTotalFee = (feeStructure) => {
  return (
    Number(feeStructure.monthlyFee || 0) +
    Number(feeStructure.admissionFee || 0) +
    Number(feeStructure.examFee || 0) +
    Number(feeStructure.transportFee || 0) +
    Number(feeStructure.otherFee || 0)
  );
};

const handleControllerError = (res, error, defaultMessage) => {
  if (error.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      message: Object.values(error.errors)
        .map((item) => item.message)
        .join(", ")
    });
  }

  if (error.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: "Invalid ID format"
    });
  }

  if (error.code === 11000) {
    return res.status(400).json({
      success: false,
      message: "Fee structure already exists for this class and session year"
    });
  }

  return res.status(500).json({
    success: false,
    message: defaultMessage,
    error: error.message
  });
};

const verifySchoolAccess = async (req, schoolId) => {
  if (!schoolId) {
    return {
      status: 400,
      response: {
        success: false,
        message: "School ID is required"
      }
    };
  }

  if (!isValidObjectId(schoolId)) {
    return {
      status: 400,
      response: {
        success: false,
        message: "Invalid school ID format"
      }
    };
  }

  if (!isSuperAdmin(req)) {
    const userSchoolId = getUserSchoolId(req);

    if (!userSchoolId) {
      return {
        status: 403,
        response: {
          success: false,
          message: "School is not assigned to this user"
        }
      };
    }

    if (userSchoolId !== schoolId.toString()) {
      return {
        status: 403,
        response: {
          success: false,
          message: "You are not allowed to access another school's data"
        }
      };
    }
  }

  const school = await School.findById(schoolId);

  if (!school) {
    return {
      status: 404,
      response: {
        success: false,
        message: "School not found"
      }
    };
  }

  return {
    school
  };
};

const verifyClassBelongsToSchool = async (classId, schoolId) => {
  if (!classId || !isValidObjectId(classId)) {
    return null;
  }

  const classData = await Class.findOne({
    _id: classId,
    schoolId
  });

  return classData;
};

exports.createFeeStructure = async (req, res) => {
  try {
    const {
      classId,
      title,
      sessionYear,
      monthlyFee,
      admissionFee,
      examFee,
      transportFee,
      otherFee
    } = req.body;

    const schoolId = getCreateSchoolId(req);

    if (!schoolId || !classId || !title || !sessionYear) {
      return res.status(400).json({
        success: false,
        message: "School ID, class ID, title and session year are required"
      });
    }

    const schoolAccess = await verifySchoolAccess(req, schoolId);

    if (schoolAccess.status) {
      return res.status(schoolAccess.status).json(schoolAccess.response);
    }

    const classData = await verifyClassBelongsToSchool(classId, schoolId);

    if (!classData) {
      return res.status(404).json({
        success: false,
        message: "Class not found or does not belong to this school"
      });
    }

    const feeStructure = await FeeStructure.create({
      schoolId,
      classId,
      title,
      sessionYear,
      monthlyFee,
      admissionFee,
      examFee,
      transportFee,
      otherFee,
      createdBy: req.user._id
    });

    await createAuditLog({
      req,
      schoolId: feeStructure.schoolId,
      action: "CREATE",
      module: "FEE_STRUCTURE",
      recordId: feeStructure._id,
      recordModel: "FeeStructure",
      description: `Fee structure created successfully: ${feeStructure.title}`,
      oldData: null,
      newData: feeStructure,
      status: "success",
      metadata: {
        title: feeStructure.title,
        sessionYear: feeStructure.sessionYear,
        classId: feeStructure.classId,
        monthlyFee: feeStructure.monthlyFee,
        admissionFee: feeStructure.admissionFee,
        examFee: feeStructure.examFee,
        transportFee: feeStructure.transportFee,
        otherFee: feeStructure.otherFee,
        totalFee: calculateTotalFee(feeStructure)
      }
    });

    res.status(201).json({
      success: true,
      message: "Fee structure created successfully",
      feeStructure
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to create fee structure"
    );
  }
};

exports.getFeeStructures = async (req, res) => {
  try {
    const filter = getSchoolFilter(req);

    if (isSuperAdmin(req) && req.query.schoolId) {
      if (!isValidObjectId(req.query.schoolId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid school ID format"
        });
      }

      filter.schoolId = req.query.schoolId;
    }

    if (req.query.classId) {
      if (!isValidObjectId(req.query.classId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid class ID format"
        });
      }

      filter.classId = req.query.classId;
    }

    if (req.query.sessionYear) {
      filter.sessionYear = req.query.sessionYear;
    }

    if (req.query.isActive !== undefined) {
      filter.isActive = req.query.isActive === "true";
    }

    if (req.query.search) {
      const searchRegex = new RegExp(req.query.search, "i");

      filter.$or = [
        { title: searchRegex },
        { sessionYear: searchRegex }
      ];
    }

    const feeStructures = await FeeStructure.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: feeStructures.length,
      feeStructures
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to fetch fee structures"
    );
  }
};

exports.getFeeStructureById = async (req, res) => {
  try {
    const feeStructure = await FeeStructure.findOne(
      getScopedFilter(req, { _id: req.params.id })
    )
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder");

    if (!feeStructure) {
      return res.status(404).json({
        success: false,
        message: "Fee structure not found or not allowed"
      });
    }

    res.status(200).json({
      success: true,
      feeStructure
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to fetch fee structure"
    );
  }
};

exports.updateFeeStructure = async (req, res) => {
  try {
    const existingFeeStructure = await FeeStructure.findOne(
      getScopedFilter(req, { _id: req.params.id })
    );

    if (!existingFeeStructure) {
      return res.status(404).json({
        success: false,
        message: "Fee structure not found or not allowed"
      });
    }

    const oldFeeStructureData = existingFeeStructure.toObject();

    if (
      req.body.schoolId &&
      req.body.schoolId.toString() !== existingFeeStructure.schoolId.toString()
    ) {
      return res.status(400).json({
        success: false,
        message: "School ID cannot be changed for fee structure"
      });
    }

    if (req.body.classId !== undefined) {
      const classData = await verifyClassBelongsToSchool(
        req.body.classId,
        existingFeeStructure.schoolId
      );

      if (!classData) {
        return res.status(404).json({
          success: false,
          message: "Class not found or does not belong to this school"
        });
      }
    }

    const allowedUpdates = {};

    const allowedFields = [
      "classId",
      "title",
      "sessionYear",
      "monthlyFee",
      "admissionFee",
      "examFee",
      "transportFee",
      "otherFee",
      "isActive"
    ];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        allowedUpdates[field] = req.body[field];
      }
    });

    allowedUpdates.updatedBy = req.user._id;

    const feeStructure = await FeeStructure.findOneAndUpdate(
      getScopedFilter(req, { _id: req.params.id }),
      allowedUpdates,
      {
        returnDocument: "after",
        runValidators: true
      }
    )
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder");

    await createAuditLog({
      req,
      schoolId: existingFeeStructure.schoolId,
      action: "UPDATE",
      module: "FEE_STRUCTURE",
      recordId: feeStructure._id,
      recordModel: "FeeStructure",
      description: `Fee structure updated successfully: ${feeStructure.title}`,
      oldData: oldFeeStructureData,
      newData: feeStructure,
      status: "success",
      metadata: {
        title: feeStructure.title,
        sessionYear: feeStructure.sessionYear,
        classId: feeStructure.classId,
        monthlyFee: feeStructure.monthlyFee,
        admissionFee: feeStructure.admissionFee,
        examFee: feeStructure.examFee,
        transportFee: feeStructure.transportFee,
        otherFee: feeStructure.otherFee,
        totalFee: calculateTotalFee(feeStructure),
        updatedFields: Object.keys(allowedUpdates).filter((field) => field !== "updatedBy")
      }
    });

    res.status(200).json({
      success: true,
      message: "Fee structure updated successfully",
      feeStructure
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to update fee structure"
    );
  }
};

exports.deleteFeeStructure = async (req, res) => {
  try {
    const feeStructure = await FeeStructure.findOneAndDelete(
      getScopedFilter(req, { _id: req.params.id })
    );

    if (!feeStructure) {
      return res.status(404).json({
        success: false,
        message: "Fee structure not found or not allowed"
      });
    }

    await createAuditLog({
      req,
      schoolId: feeStructure.schoolId,
      action: "DELETE",
      module: "FEE_STRUCTURE",
      recordId: feeStructure._id,
      recordModel: "FeeStructure",
      description: `Fee structure deleted successfully: ${feeStructure.title}`,
      oldData: feeStructure,
      newData: null,
      status: "success",
      metadata: {
        title: feeStructure.title,
        sessionYear: feeStructure.sessionYear,
        classId: feeStructure.classId,
        monthlyFee: feeStructure.monthlyFee,
        admissionFee: feeStructure.admissionFee,
        examFee: feeStructure.examFee,
        transportFee: feeStructure.transportFee,
        otherFee: feeStructure.otherFee,
        totalFee: calculateTotalFee(feeStructure)
      }
    });

    res.status(200).json({
      success: true,
      message: "Fee structure deleted successfully"
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to delete fee structure"
    );
  }
};