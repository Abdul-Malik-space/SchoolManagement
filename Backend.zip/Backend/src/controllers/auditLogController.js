const mongoose = require("mongoose");
const AuditLog = require("../models/AuditLog");

const {
  getPaginationOptions,
  buildPagination
} = require("../utils/pagination");

const isValidObjectId = (id) => {
  return id && mongoose.Types.ObjectId.isValid(id);
};

const getUserSchoolId = (req) => {
  const schoolId = req.user && req.user.schoolId;

  if (!schoolId) {
    return null;
  }

  if (schoolId._id) {
    return schoolId._id.toString();
  }

  return schoolId.toString();
};

const parseDate = (dateValue) => {
  const parsedDate = new Date(dateValue);

  if (Number.isNaN(parsedDate.getTime())) {
    return null;
  }

  return parsedDate;
};

const handleControllerError = (res, error, defaultMessage) => {
  if (error.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: "Invalid ID format"
    });
  }

  return res.status(500).json({
    success: false,
    message: defaultMessage,
    error: error.message
  });
};

const getSchoolFilterForLogs = (req) => {
  if (req.user.role === "super_admin") {
    if (req.query.schoolId) {
      if (!isValidObjectId(req.query.schoolId)) {
        return {
          error: "Invalid school ID format"
        };
      }

      return {
        schoolId: req.query.schoolId
      };
    }

    return {};
  }

  const userSchoolId = getUserSchoolId(req);

  if (!userSchoolId) {
    return null;
  }

  return {
    schoolId: userSchoolId
  };
};

exports.getAuditLogs = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationOptions(req.query);

    const schoolFilter = getSchoolFilterForLogs(req);

    if (schoolFilter === null) {
      return res.status(403).json({
        success: false,
        message: "School is not assigned to this user"
      });
    }

    if (schoolFilter.error) {
      return res.status(400).json({
        success: false,
        message: schoolFilter.error
      });
    }

    const filter = {
      ...schoolFilter
    };

    if (req.query.userId) {
      if (!isValidObjectId(req.query.userId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user ID format"
        });
      }

      filter.userId = req.query.userId;
    }

    if (req.query.userRole) {
      filter.userRole = req.query.userRole;
    }

    if (req.query.action) {
      filter.action = req.query.action;
    }

    if (req.query.module) {
      filter.module = req.query.module;
    }

    if (req.query.status) {
      const allowedStatuses = ["success", "failed"];

      if (!allowedStatuses.includes(req.query.status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid status"
        });
      }

      filter.status = req.query.status;
    }

    if (req.query.recordId) {
      if (!isValidObjectId(req.query.recordId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid record ID format"
        });
      }

      filter.recordId = req.query.recordId;
    }

    if (req.query.recordModel) {
      filter.recordModel = req.query.recordModel;
    }

    if (req.query.fromDate || req.query.toDate) {
      filter.createdAt = {};

      if (req.query.fromDate) {
        const fromDate = parseDate(req.query.fromDate);

        if (!fromDate) {
          return res.status(400).json({
            success: false,
            message: "Invalid fromDate format"
          });
        }

        fromDate.setHours(0, 0, 0, 0);
        filter.createdAt.$gte = fromDate;
      }

      if (req.query.toDate) {
        const toDate = parseDate(req.query.toDate);

        if (!toDate) {
          return res.status(400).json({
            success: false,
            message: "Invalid toDate format"
          });
        }

        toDate.setHours(23, 59, 59, 999);
        filter.createdAt.$lte = toDate;
      }
    }

    if (req.query.search) {
      const searchRegex = new RegExp(req.query.search, "i");

      filter.$or = [
        { userName: searchRegex },
        { userEmail: searchRegex },
        { userRole: searchRegex },
        { action: searchRegex },
        { module: searchRegex },
        { recordModel: searchRegex },
        { description: searchRegex }
      ];
    }

    const total = await AuditLog.countDocuments(filter);

    const auditLogs = await AuditLog.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("userId", "name email role")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      count: auditLogs.length,
      pagination: buildPagination({ total, page, limit }),
      auditLogs
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to fetch audit logs"
    );
  }
};

exports.getAuditLogById = async (req, res) => {
  try {
    const schoolFilter = getSchoolFilterForLogs(req);

    if (schoolFilter === null) {
      return res.status(403).json({
        success: false,
        message: "School is not assigned to this user"
      });
    }

    if (schoolFilter.error) {
      return res.status(400).json({
        success: false,
        message: schoolFilter.error
      });
    }

    const filter = {
      _id: req.params.id,
      ...schoolFilter
    };

    const auditLog = await AuditLog.findOne(filter)
      .populate("schoolId", "schoolName type")
      .populate("userId", "name email role");

    if (!auditLog) {
      return res.status(404).json({
        success: false,
        message: "Audit log not found or not allowed"
      });
    }

    res.status(200).json({
      success: true,
      auditLog
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to fetch audit log"
    );
  }
};

exports.deleteAuditLog = async (req, res) => {
  try {
    if (req.user.role !== "super_admin") {
      return res.status(403).json({
        success: false,
        message: "Only super admin can delete audit logs"
      });
    }

    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid ID format"
      });
    }

    const auditLog = await AuditLog.findByIdAndDelete(req.params.id);

    if (!auditLog) {
      return res.status(404).json({
        success: false,
        message: "Audit log not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Audit log deleted successfully"
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Failed to delete audit log"
    );
  }
};