const mongoose = require("mongoose");

const Student = require("../models/Student");
const Teacher = require("../models/Teacher");
const Class = require("../models/Class");
const Subject = require("../models/Subject");
const StudentAttendance = require("../models/StudentAttendance");
const FeeCollection = require("../models/FeeCollection");

/*
|--------------------------------------------------------------------------
| Normalize date
|--------------------------------------------------------------------------
*/

const normalizeDate = (date) => {
  const normalized = new Date(date);

  if (Number.isNaN(normalized.getTime())) {
    return null;
  }

  normalized.setHours(0, 0, 0, 0);

  return normalized;
};

/*
|--------------------------------------------------------------------------
| Check Super Admin
|--------------------------------------------------------------------------
*/

const isSuperAdmin = (req) => {
  return req.user && req.user.role === "super_admin";
};

/*
|--------------------------------------------------------------------------
| Get logged-in user's school ID
|--------------------------------------------------------------------------
*/

const getUserSchoolId = (req) => {
  const schoolId = req.user && req.user.schoolId;

  if (!schoolId) {
    return null;
  }

  if (schoolId._id) {
    return schoolId._id.toString();
  }

  return schoolId.toString();
};

/*
|--------------------------------------------------------------------------
| Build school filters
|--------------------------------------------------------------------------
*/

const buildSchoolFilters = (req) => {
  let schoolId = null;

  /*
  |--------------------------------------------------------------------------
  | Super Admin school filter
  |--------------------------------------------------------------------------
  */

  if (isSuperAdmin(req)) {
    if (req.query.schoolId) {
      schoolId = req.query.schoolId;
    }
  }

  /*
  |--------------------------------------------------------------------------
  | Middleware school filter
  |--------------------------------------------------------------------------
  */

  else if (req.schoolFilter && req.schoolFilter.schoolId) {
    schoolId = req.schoolFilter.schoolId.toString();
  }

  /*
  |--------------------------------------------------------------------------
  | Logged-in user's school
  |--------------------------------------------------------------------------
  */

  else {
    schoolId = getUserSchoolId(req);
  }

  /*
  |--------------------------------------------------------------------------
  | No school selected
  |--------------------------------------------------------------------------
  */

  if (!schoolId) {
    /*
    | Super Admin can view all schools.
    */

    if (isSuperAdmin(req)) {
      return {
        filter: {},
        aggregateMatch: {}
      };
    }

    /*
    | Other users without a school should not receive another school's data.
    */

    return {
      filter: {
        schoolId: null
      },
      aggregateMatch: {
        schoolId: null
      }
    };
  }

  /*
  |--------------------------------------------------------------------------
  | Validate school ID
  |--------------------------------------------------------------------------
  */

  if (!mongoose.Types.ObjectId.isValid(schoolId)) {
    return {
      error: "Invalid school ID"
    };
  }

  return {
    filter: {
      schoolId
    },

    aggregateMatch: {
      schoolId: new mongoose.Types.ObjectId(schoolId)
    }
  };
};

/*
|--------------------------------------------------------------------------
| Get dashboard summary
|--------------------------------------------------------------------------
*/

exports.getDashboardSummary = async (req, res) => {
  try {
    const { month, date } = req.query;

    /*
    |--------------------------------------------------------------------------
    | Build school-based query filters
    |--------------------------------------------------------------------------
    */

    const schoolFilters = buildSchoolFilters(req);

    if (schoolFilters.error) {
      return res.status(400).json({
        success: false,
        message: schoolFilters.error
      });
    }

    const { filter, aggregateMatch } = schoolFilters;

    /*
    |--------------------------------------------------------------------------
    | Validate selected month
    |--------------------------------------------------------------------------
    */

    const selectedMonth =
      month || new Date().toISOString().slice(0, 7);

    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(selectedMonth)) {
      return res.status(400).json({
        success: false,
        message: "Invalid month format. Use YYYY-MM"
      });
    }

    /*
    |--------------------------------------------------------------------------
    | Validate selected attendance date
    |--------------------------------------------------------------------------
    */

    const selectedDate = normalizeDate(date || new Date());

    if (!selectedDate) {
      return res.status(400).json({
        success: false,
        message: "Invalid date format"
      });
    }

    /*
    |--------------------------------------------------------------------------
    | Dashboard totals
    |--------------------------------------------------------------------------
    |
    | Soft-deleted records are excluded from all dashboard totals.
    |
    */

    const totalStudents = await Student.countDocuments({
      ...filter,
      status: "active",
      isDeleted: { $ne: true }
    });

    const totalTeachers = await Teacher.countDocuments({
      ...filter,
      status: "active",
      isDeleted: { $ne: true }
    });

    const totalClasses = await Class.countDocuments({
      ...filter,
      isActive: true,
      isDeleted: { $ne: true }
    });

    const totalSubjects = await Subject.countDocuments({
      ...filter,
      isActive: true,
      isDeleted: { $ne: true }
    });

    /*
    |--------------------------------------------------------------------------
    | Recent student admissions
    |--------------------------------------------------------------------------
    |
    | Deleted students are excluded.
    |
    */

    const recentStudents = await Student.find({
      ...filter,
      isDeleted: { $ne: true }
    })
      .populate("classId", "className")
      .sort({
        createdAt: -1
      })
      .limit(5)
      .select(
        "name fatherName admissionNumber sectionName createdAt classId status"
      );

    /*
    |--------------------------------------------------------------------------
    | Student attendance summary
    |--------------------------------------------------------------------------
    */

    const attendanceSummary = await StudentAttendance.aggregate([
      {
        $match: {
          ...aggregateMatch,
          attendanceDate: selectedDate
        }
      },
      {
        $unwind: "$records"
      },
      {
        $group: {
          _id: "$records.status",
          count: {
            $sum: 1
          }
        }
      }
    ]);

    const attendance = {
      present: 0,
      absent: 0,
      leave: 0
    };

    attendanceSummary.forEach((item) => {
      if (
        item._id &&
        Object.prototype.hasOwnProperty.call(
          attendance,
          item._id
        )
      ) {
        attendance[item._id] = item.count;
      }
    });

    /*
    |--------------------------------------------------------------------------
    | Fee filters
    |--------------------------------------------------------------------------
    */

    const feeMonthFilter = {
      ...filter,
      feeMonth: selectedMonth
    };

    /*
    |--------------------------------------------------------------------------
    | Monthly fee totals
    |--------------------------------------------------------------------------
    */

    const monthlyFeeCollection = await FeeCollection.aggregate([
      {
        $match: {
          ...aggregateMatch,
          feeMonth: selectedMonth
        }
      },
      {
        $group: {
          _id: null,

          totalCollected: {
            $sum: "$paidAmount"
          },

          totalPayable: {
            $sum: "$payableAmount"
          },

          totalPending: {
            $sum: "$balanceAmount"
          }
        }
      }
    ]);

    const feeStats = monthlyFeeCollection[0] || {
      totalCollected: 0,
      totalPayable: 0,
      totalPending: 0
    };

    /*
    |--------------------------------------------------------------------------
    | Fee payment statuses
    |--------------------------------------------------------------------------
    */

    const paidFeeRecords =
      await FeeCollection.countDocuments({
        ...feeMonthFilter,
        paymentStatus: "paid"
      });

    const partialFeeRecords =
      await FeeCollection.countDocuments({
        ...feeMonthFilter,
        paymentStatus: "partial"
      });

    const unpaidFeeRecords =
      await FeeCollection.countDocuments({
        ...feeMonthFilter,
        paymentStatus: "unpaid"
      });

    /*
    |--------------------------------------------------------------------------
    | Send dashboard response
    |--------------------------------------------------------------------------
    */

    return res.status(200).json({
      success: true,
      message: "Dashboard summary fetched successfully",

      summary: {
        totalStudents,
        totalTeachers,
        totalClasses,
        totalSubjects,

        attendanceDate: selectedDate,

        todayAttendance: {
          present: attendance.present,
          absent: attendance.absent,
          leave: attendance.leave
        },

        feeMonth: selectedMonth,

        monthlyRevenue: feeStats.totalCollected,
        monthlyPayable: feeStats.totalPayable,
        pendingFees: feeStats.totalPending,

        feeStatus: {
          paid: paidFeeRecords,
          partial: partialFeeRecords,
          unpaid: unpaidFeeRecords
        },

        recentAdmissions: recentStudents
      }
    });
  } catch (error) {
    console.error(
      "Dashboard summary error:",
      error.message
    );

    return res.status(500).json({
      success: false,
      message: "Failed to fetch dashboard summary",
      error: error.message
    });
  }
};