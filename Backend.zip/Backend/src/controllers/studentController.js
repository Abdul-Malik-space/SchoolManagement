const Student = require("../models/Student");
const School = require("../models/School");
const Class = require("../models/Class");

const {
  getPaginationOptions,
  buildPagination
} = require("../utils/pagination");

const {
  createAuditLog
} = require("../utils/auditLogHelper");

const generateAdmissionNumber = () => {
  const year = new Date().getFullYear();
  const randomNumber = Math.floor(100000 + Math.random() * 900000);
  return `ADM-${year}-${randomNumber}`;
};

const generateUniqueAdmissionNumber = async (schoolId) => {
  let admissionNumber;
  let exists = true;
  let attempts = 0;

  while (exists && attempts < 10) {
    admissionNumber = generateAdmissionNumber();

    exists = await Student.findOne({
      schoolId,
      admissionNumber
    }).select("_id");

    attempts += 1;
  }

  if (exists) {
    throw new Error("Failed to generate unique admission number");
  }

  return admissionNumber;
};

const isSuperAdmin = (req) => {
  return req.user && req.user.role === "super_admin";
};

const getUserSchoolId = (req) => {
  const schoolId = req.user && req.user.schoolId;

  if (!schoolId) {
    return null;
  }

  if (schoolId._id) {
    return schoolId._id.toString();
  }

  return schoolId.toString();
};

const getSchoolFilter = (req) => {
  if (isSuperAdmin(req)) {
    return {};
  }

  if (req.schoolFilter && Object.keys(req.schoolFilter).length > 0) {
    return { ...req.schoolFilter };
  }

  const userSchoolId = getUserSchoolId(req);

  if (!userSchoolId) {
    return { schoolId: null };
  }

  return { schoolId: userSchoolId };
};

const getCreateSchoolId = (req) => {
  if (isSuperAdmin(req)) {
    return req.body.schoolId;
  }

  return getUserSchoolId(req);
};

const getPlainData = (document) => {
  if (!document) {
    return null;
  }

  if (typeof document.toObject === "function") {
    return document.toObject();
  }

  return document;
};

const buildStudentFilter = (req, deletedStatus = false) => {
  const filter = {
    ...getSchoolFilter(req)
  };

  if (deletedStatus === true) {
    // Only soft deleted students
    filter.isDeleted = true;
  } else {
    // Active/non-deleted students
    // This also includes old records where isDeleted field does not exist
    filter.isDeleted = { $ne: true };
  }

  if (isSuperAdmin(req) && req.query.schoolId) {
    filter.schoolId = req.query.schoolId;
  }

  if (req.query.classId) {
    filter.classId = req.query.classId;
  }

  if (req.query.sectionId) {
    filter.sectionId = req.query.sectionId;
  }

  if (req.query.sectionName) {
    filter.sectionName = req.query.sectionName;
  }

  if (req.query.status) {
    filter.status = req.query.status;
  }

  if (req.query.gender) {
    filter.gender = req.query.gender;
  }

  if (req.query.search) {
    const searchRegex = new RegExp(req.query.search, "i");

    filter.$or = [
      { name: searchRegex },
      { fatherName: searchRegex },
      { admissionNumber: searchRegex },
      { bForm: searchRegex },
      { contactNumber: searchRegex },
      { guardianName: searchRegex },
      { guardianContact: searchRegex }
    ];
  }

  return filter;
};

exports.createStudent = async (req, res) => {
  try {
    const {
      classId,
      sectionId,
      name,
      fatherName,
      bForm,
      dateOfBirth,
      gender,
      address,
      contactNumber,
      guardianName,
      guardianContact,
      admissionDate,
      studentPhoto
    } = req.body;

    const schoolId = getCreateSchoolId(req);

    if (!schoolId || !classId || !sectionId || !name || !fatherName || !gender) {
      return res.status(400).json({
        success: false,
        message: "School ID, class ID, section ID, name, father name and gender are required"
      });
    }

    const school = await School.findById(schoolId);

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found"
      });
    }

    const classData = await Class.findOne({
      _id: classId,
      schoolId,
      isDeleted: { $ne: true }
    });

    if (!classData) {
      return res.status(404).json({
        success: false,
        message: "Class not found in this school"
      });
    }

    const section = classData.sections.id(sectionId);

    if (!section) {
      return res.status(404).json({
        success: false,
        message: "Section not found in this class"
      });
    }

    const admissionNumber = await generateUniqueAdmissionNumber(schoolId);

    const student = await Student.create({
      schoolId,
      classId,
      sectionId,
      sectionName: section.sectionName,
      admissionNumber,
      name,
      fatherName,
      bForm,
      dateOfBirth,
      gender,
      address,
      contactNumber,
      guardianName,
      guardianContact,
      admissionDate,
      studentPhoto,
      createdBy: req.user._id,
      isDeleted: false,
      deletedAt: null,
      deletedBy: null
    });

    await createAuditLog({
      req,
      schoolId: student.schoolId,
      action: "CREATE",
      module: "STUDENT",
      recordId: student._id,
      recordModel: "Student",
      description: `Student created successfully: ${student.name}`,
      oldData: null,
      newData: getPlainData(student),
      status: "success",
      metadata: {
        admissionNumber: student.admissionNumber,
        classId: student.classId,
        sectionId: student.sectionId,
        sectionName: student.sectionName
      }
    });

    res.status(201).json({
      success: true,
      message: "Student created successfully",
      student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to create student",
      error: error.message
    });
  }
};

exports.getStudents = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationOptions(req.query);

    const filter = buildStudentFilter(req, false);

    const total = await Student.countDocuments(filter);

    const students = await Student.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder")
      .populate("studentUserId", "name email role")
      .populate("parentUserIds", "name email role")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      count: students.length,
      pagination: buildPagination({ total, page, limit }),
      students
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch students",
      error: error.message
    });
  }
};

exports.getDeletedStudents = async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationOptions(req.query);

    const filter = buildStudentFilter(req, true);

    const total = await Student.countDocuments(filter);

    const students = await Student.find(filter)
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder")
      .populate("studentUserId", "name email role")
      .populate("parentUserIds", "name email role")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role")
      .populate("deletedBy", "name email role")
      .sort({ deletedAt: -1, updatedAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      count: students.length,
      pagination: buildPagination({ total, page, limit }),
      students
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch deleted students",
      error: error.message
    });
  }
};

exports.getStudentById = async (req, res) => {
  try {
    const filter = {
      _id: req.params.id,
      ...getSchoolFilter(req),
      isDeleted: false
    };

    const student = await Student.findOne(filter)
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder")
      .populate("studentUserId", "name email role")
      .populate("parentUserIds", "name email role")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role");

    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    res.status(200).json({
      success: true,
      student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to fetch student",
      error: error.message
    });
  }
};

exports.updateStudent = async (req, res) => {
  try {
    const filter = {
      _id: req.params.id,
      ...getSchoolFilter(req),
      isDeleted: false
    };

    const existingStudent = await Student.findOne(filter);

    if (!existingStudent) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    const oldStudentData = getPlainData(existingStudent);

    const updateData = { ...req.body };

    delete updateData.schoolId;
    delete updateData.admissionNumber;
    delete updateData.sectionName;
    delete updateData.createdBy;
    delete updateData.updatedBy;
    delete updateData.isDeleted;
    delete updateData.deletedAt;
    delete updateData.deletedBy;

    if (updateData.classId || updateData.sectionId) {
      const finalClassId = updateData.classId || existingStudent.classId;
      const finalSectionId = updateData.sectionId || existingStudent.sectionId;

      const classData = await Class.findOne({
        _id: finalClassId,
        schoolId: existingStudent.schoolId,
        isDeleted: { $ne: true }
      });

      if (!classData) {
        return res.status(404).json({
          success: false,
          message: "Class not found in this school"
        });
      }

      const section = classData.sections.id(finalSectionId);

      if (!section) {
        return res.status(404).json({
          success: false,
          message: "Section not found in this class"
        });
      }

      updateData.sectionName = section.sectionName;
    }

    updateData.updatedBy = req.user._id;

    const student = await Student.findOneAndUpdate(
      filter,
      updateData,
      {
        returnDocument: "after",
        runValidators: true
      }
    )
      .populate("schoolId", "schoolName type")
      .populate("classId", "className numericOrder")
      .populate("studentUserId", "name email role")
      .populate("parentUserIds", "name email role")
      .populate("createdBy", "name email role")
      .populate("updatedBy", "name email role");

    await createAuditLog({
      req,
      schoolId: student.schoolId,
      action: "UPDATE",
      module: "STUDENT",
      recordId: student._id,
      recordModel: "Student",
      description: `Student updated successfully: ${student.name}`,
      oldData: oldStudentData,
      newData: getPlainData(student),
      status: "success",
      metadata: {
        admissionNumber: student.admissionNumber,
        updatedFields: Object.keys(updateData)
      }
    });

    res.status(200).json({
      success: true,
      message: "Student updated successfully",
      student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to update student",
      error: error.message
    });
  }
};

exports.deleteStudent = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);

    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    if (student.isDeleted === true) {
      return res.status(400).json({
        success: false,
        message: "Student is already deleted"
      });
    }

    if (!isSuperAdmin(req)) {
      const userSchoolId = getUserSchoolId(req);

      if (!userSchoolId) {
        return res.status(403).json({
          success: false,
          message: "School is not assigned to this user"
        });
      }

      if (student.schoolId.toString() !== userSchoolId.toString()) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to delete another school's student"
        });
      }
    }

    const oldStudentData = getPlainData(student);

    student.isDeleted = true;
    student.deletedAt = new Date();
    student.deletedBy = req.user._id;
    student.updatedBy = req.user._id;

    await student.save();

    await createAuditLog({
      req,
      schoolId: student.schoolId,
      action: "DELETE",
      module: "STUDENT",
      recordId: student._id,
      recordModel: "Student",
      description: `Student soft deleted successfully: ${student.name}`,
      oldData: oldStudentData,
      newData: getPlainData(student),
      status: "success",
      metadata: {
        admissionNumber: student.admissionNumber,
        classId: student.classId,
        sectionId: student.sectionId,
        sectionName: student.sectionName,
        deletedAt: student.deletedAt,
        softDelete: true
      }
    });

    res.status(200).json({
      success: true,
      message: "Student deleted successfully",
      student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete student",
      error: error.message
    });
  }
};

exports.restoreStudent = async (req, res) => {
  try {
    const filter = {
      _id: req.params.id,
      ...getSchoolFilter(req),
      isDeleted: true
    };

    const existingStudent = await Student.findOne(filter);

    if (!existingStudent) {
      return res.status(404).json({
        success: false,
        message: "Deleted student not found"
      });
    }

    const oldStudentData = getPlainData(existingStudent);

    existingStudent.isDeleted = false;
    existingStudent.deletedAt = null;
    existingStudent.deletedBy = null;
    existingStudent.updatedBy = req.user._id;

    await existingStudent.save();

    await existingStudent.populate([
      { path: "schoolId", select: "schoolName type" },
      { path: "classId", select: "className numericOrder" },
      { path: "studentUserId", select: "name email role" },
      { path: "parentUserIds", select: "name email role" },
      { path: "createdBy", select: "name email role" },
      { path: "updatedBy", select: "name email role" }
    ]);

    await createAuditLog({
      req,
      schoolId: existingStudent.schoolId,
      action: "UPDATE",
      module: "STUDENT",
      recordId: existingStudent._id,
      recordModel: "Student",
      description: `Student restored successfully: ${existingStudent.name}`,
      oldData: oldStudentData,
      newData: getPlainData(existingStudent),
      status: "success",
      metadata: {
        admissionNumber: existingStudent.admissionNumber,
        classId: existingStudent.classId,
        sectionId: existingStudent.sectionId,
        sectionName: existingStudent.sectionName,
        restored: true
      }
    });

    res.status(200).json({
      success: true,
      message: "Student restored successfully",
      student: existingStudent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to restore student",
      error: error.message
    });
  }
};