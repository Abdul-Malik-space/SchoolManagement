const mongoose = require("mongoose");

const teacherSchema = new mongoose.Schema(
  {
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: [true, "School ID is required"]
    },

    employeeId: {
      type: String,
      required: true
    },

    name: {
      type: String,
      required: [true, "Teacher name is required"],
      trim: true
    },

    fatherName: {
      type: String,
      trim: true,
      default: ""
    },

    email: {
      type: String,
      lowercase: true,
      trim: true,
      default: ""
    },

    phone: {
      type: String,
      required: [true, "Phone number is required"],
      trim: true
    },

    cnic: {
      type: String,
      trim: true,
      default: ""
    },

    gender: {
      type: String,
      enum: ["male", "female", "other"],
      required: [true, "Gender is required"]
    },

    dateOfBirth: {
      type: Date
    },

    address: {
      type: String,
      default: ""
    },

    qualification: {
      type: String,
      required: [true, "Qualification is required"],
      trim: true
    },

    subjects: [
      {
        type: String,
        trim: true
      }
    ],

    salary: {
      type: Number,
      default: 0
    },

    joiningDate: {
      type: Date,
      default: Date.now
    },

    teacherPhoto: {
      type: String,
      default: ""
    },

    status: {
      type: String,
      enum: ["active", "inactive", "resigned"],
      default: "active"
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    },

    isDeleted: {
      type: Boolean,
      default: false
    },

    deletedAt: {
      type: Date,
      default: null
    },

    deletedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    }
  },
  {
    timestamps: true
  }
);

teacherSchema.index({ schoolId: 1, employeeId: 1 }, { unique: true });
teacherSchema.index({ schoolId: 1, isDeleted: 1 });
teacherSchema.index({ schoolId: 1, status: 1, isDeleted: 1 });

module.exports = mongoose.model("Teacher", teacherSchema);