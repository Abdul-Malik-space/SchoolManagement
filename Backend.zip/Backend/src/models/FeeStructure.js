const mongoose = require("mongoose");

const feeStructureSchema = new mongoose.Schema(
  {
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: [true, "School ID is required"]
    },

    classId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Class",
      required: [true, "Class ID is required"]
    },

    title: {
      type: String,
      required: [true, "Fee title is required"],
      trim: true
    },

    sessionYear: {
      type: String,
      required: [true, "Session year is required"],
      trim: true
    },

    monthlyFee: {
      type: Number,
      default: 0,
      min: [0, "Monthly fee cannot be negative"]
    },

    admissionFee: {
      type: Number,
      default: 0,
      min: [0, "Admission fee cannot be negative"]
    },

    examFee: {
      type: Number,
      default: 0,
      min: [0, "Exam fee cannot be negative"]
    },

    transportFee: {
      type: Number,
      default: 0,
      min: [0, "Transport fee cannot be negative"]
    },

    otherFee: {
      type: Number,
      default: 0,
      min: [0, "Other fee cannot be negative"]
    },

    isActive: {
      type: Boolean,
      default: true
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  },
  {
    timestamps: true
  }
);

feeStructureSchema.index(
  { schoolId: 1, classId: 1, sessionYear: 1 },
  { unique: true }
);

module.exports = mongoose.model("FeeStructure", feeStructureSchema);