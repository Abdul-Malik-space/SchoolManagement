const mongoose = require("mongoose");

const attendanceRecordSchema = new mongoose.Schema(
  {
    studentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Student",
      required: true
    },

    status: {
      type: String,
      enum: ["present", "absent", "leave"],
      required: true
    },

    remarks: {
      type: String,
      default: ""
    }
  },
  {
    _id: false
  }
);

const studentAttendanceSchema = new mongoose.Schema(
  {
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: [true, "School ID is required"]
    },

    classId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Class",
      required: [true, "Class ID is required"]
    },

    sectionName: {
      type: String,
      required: [true, "Section name is required"],
      trim: true
    },

    attendanceDate: {
      type: Date,
      required: [true, "Attendance date is required"]
    },

    records: {
      type: [attendanceRecordSchema],
      required: true,
      validate: {
        validator: function (records) {
          return records.length > 0;
        },
        message: "At least one attendance record is required"
      }
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  },
  {
    timestamps: true
  }
);

studentAttendanceSchema.index(
  { schoolId: 1, classId: 1, sectionName: 1, attendanceDate: 1 },
  { unique: true }
);

module.exports = mongoose.model("StudentAttendance", studentAttendanceSchema);