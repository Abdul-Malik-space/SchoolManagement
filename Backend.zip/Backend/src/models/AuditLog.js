const mongoose = require("mongoose");

const auditLogSchema = new mongoose.Schema(
  {
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      default: null,
      index: true
    },

    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },

    userName: {
      type: String,
      trim: true,
      default: ""
    },

    userEmail: {
      type: String,
      trim: true,
      default: ""
    },

    userRole: {
      type: String,
      trim: true,
      required: true
    },

    action: {
      type: String,
      required: true,
      trim: true,
      enum: [
        "CREATE",
        "READ",
        "UPDATE",
        "DELETE",
        "LOGIN",
        "LOGOUT",
        "PASSWORD_CHANGE",
        "STATUS_CHANGE",
        "PAYMENT",
        "ATTENDANCE",
        "OTHER"
      ],
      index: true
    },

    module: {
      type: String,
      required: true,
      trim: true,
      index: true
    },

    recordId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
      index: true
    },

    recordModel: {
      type: String,
      trim: true,
      default: ""
    },

    description: {
      type: String,
      trim: true,
      default: ""
    },

    oldData: {
      type: mongoose.Schema.Types.Mixed,
      default: null
    },

    newData: {
      type: mongoose.Schema.Types.Mixed,
      default: null
    },

    ipAddress: {
      type: String,
      trim: true,
      default: ""
    },

    userAgent: {
      type: String,
      trim: true,
      default: ""
    },

    status: {
      type: String,
      enum: ["success", "failed"],
      default: "success",
      index: true
    },

    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: null
    }
  },
  {
    timestamps: true
  }
);

auditLogSchema.index({ schoolId: 1, createdAt: -1 });
auditLogSchema.index({ userId: 1, createdAt: -1 });
auditLogSchema.index({ module: 1, action: 1 });
auditLogSchema.index({ createdAt: -1 });

module.exports = mongoose.model("AuditLog", auditLogSchema);