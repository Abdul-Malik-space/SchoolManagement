const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    amount: {
      type: Number,
      required: true
    },

    paymentMethod: {
      type: String,
      enum: ["cash", "bank", "online", "cheque"],
      default: "cash"
    },

    paymentDate: {
      type: Date,
      default: Date.now
    },

    remarks: {
      type: String,
      default: ""
    },

    receivedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  },
  {
    timestamps: true
  }
);

const feeCollectionSchema = new mongoose.Schema(
  {
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: true
    },

    studentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Student",
      required: true
    },

    classId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Class",
      required: true
    },

    feeStructureId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FeeStructure",
      required: true
    },

    feeMonth: {
      type: String,
      required: true
    },

    sessionYear: {
      type: String,
      required: true
    },

    invoiceNumber: {
      type: String,
      required: true,
      unique: true
    },

    monthlyFee: {
      type: Number,
      default: 0
    },

    admissionFee: {
      type: Number,
      default: 0
    },

    examFee: {
      type: Number,
      default: 0
    },

    transportFee: {
      type: Number,
      default: 0
    },

    otherFee: {
      type: Number,
      default: 0
    },

    discount: {
      type: Number,
      default: 0
    },

    fine: {
      type: Number,
      default: 0
    },

    totalAmount: {
      type: Number,
      default: 0
    },

    payableAmount: {
      type: Number,
      default: 0
    },

    paidAmount: {
      type: Number,
      default: 0
    },

    balanceAmount: {
      type: Number,
      default: 0
    },

    paymentStatus: {
      type: String,
      enum: ["unpaid", "partial", "paid"],
      default: "unpaid"
    },

    payments: [paymentSchema],

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  },
  {
    timestamps: true
  }
);

feeCollectionSchema.index(
  { schoolId: 1, studentId: 1, feeMonth: 1, sessionYear: 1 },
  { unique: true }
);

feeCollectionSchema.pre("save", function () {
  this.totalAmount =
    Number(this.monthlyFee || 0) +
    Number(this.admissionFee || 0) +
    Number(this.examFee || 0) +
    Number(this.transportFee || 0) +
    Number(this.otherFee || 0);

  this.payableAmount =
    Number(this.totalAmount || 0) +
    Number(this.fine || 0) -
    Number(this.discount || 0);

  this.paidAmount = this.payments.reduce((sum, payment) => {
    return sum + Number(payment.amount || 0);
  }, 0);

  this.balanceAmount = this.payableAmount - this.paidAmount;

  if (this.paidAmount <= 0) {
    this.paymentStatus = "unpaid";
  } else if (this.paidAmount < this.payableAmount) {
    this.paymentStatus = "partial";
  } else {
    this.paymentStatus = "paid";
    this.balanceAmount = 0;
  }
});

module.exports = mongoose.model("FeeCollection", feeCollectionSchema);