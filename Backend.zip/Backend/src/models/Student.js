const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema(
  {
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: [true, "School ID is required"]
    },

    classId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Class",
      required: [true, "Class ID is required"]
    },

    sectionId: {
      type: mongoose.Schema.Types.ObjectId,
      required: [true, "Section ID is required"]
    },

    sectionName: {
      type: String,
      required: [true, "Section name is required"]
    },

    studentUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    },

    parentUserIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    admissionNumber: {
      type: String,
      required: true
    },

    name: {
      type: String,
      required: [true, "Student name is required"],
      trim: true
    },

    fatherName: {
      type: String,
      required: [true, "Father name is required"],
      trim: true
    },

    bForm: {
      type: String,
      trim: true,
      default: ""
    },

    dateOfBirth: {
      type: Date
    },

    gender: {
      type: String,
      enum: ["male", "female", "other"],
      required: [true, "Gender is required"]
    },

    address: {
      type: String,
      default: ""
    },

    contactNumber: {
      type: String,
      default: ""
    },

    guardianName: {
      type: String,
      default: ""
    },

    guardianContact: {
      type: String,
      default: ""
    },

    admissionDate: {
      type: Date,
      default: Date.now
    },

    studentPhoto: {
      type: String,
      default: ""
    },

    status: {
      type: String,
      enum: ["active", "inactive", "transferred", "passed_out"],
      default: "active"
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    },

    isDeleted: {
      type: Boolean,
      default: false
    },

    deletedAt: {
      type: Date,
      default: null
    },

    deletedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    }
  },
  {
    timestamps: true
  }
);

studentSchema.index({ schoolId: 1, admissionNumber: 1 }, { unique: true });
studentSchema.index({ studentUserId: 1 }, { unique: true, sparse: true });
studentSchema.index({ schoolId: 1, isDeleted: 1 });
studentSchema.index({ schoolId: 1, classId: 1, sectionId: 1, isDeleted: 1 });
studentSchema.index({ schoolId: 1, status: 1, isDeleted: 1 });

module.exports = mongoose.model("Student", studentSchema);