import { useEffect, useState } from "react";
import {
  GraduationCap,
  Users,
  School,
  BookOpen,
  Wallet,
  CheckCircle2,
  XCircle,
  Clock
} from "lucide-react";
import { getDashboardSummary } from "../../api/dashboard";
import { StatCard } from "../../components/ui/StatCard";
import { PageHeader } from "../../components/ui/PageHeader";

const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        const { data } = await getDashboardSummary();
        setSummary(data?.summary || null);
      } catch (error) {
        setSummary(null);
      } finally {
        setLoading(false);
      }
    };

    fetchSummary();
  }, []);

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
      </div>
    );
  }

  const admissions = summary?.recentAdmissions || [];

  return (
    <div>
      <PageHeader title="Dashboard" />

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <StatCard label="Students" value={summary?.totalStudents ?? 0} icon={GraduationCap} tone="brand" />
        <StatCard label="Teachers" value={summary?.totalTeachers ?? 0} icon={Users} tone="amber" />
        <StatCard label="Classes" value={summary?.totalClasses ?? 0} icon={School} tone="slate" />
        <StatCard label="Subjects" value={summary?.totalSubjects ?? 0} icon={BookOpen} tone="rose" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-1">
          <p className="mb-4 text-xs font-semibold uppercase tracking-wide text-slate-500">
            Today's Attendance
          </p>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm text-slate-600">
                <CheckCircle2 size={15} className="text-emerald-500" /> Present
              </span>
              <span className="text-sm font-semibold text-slate-800">
                {summary?.todayAttendance?.present ?? 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm text-slate-600">
                <XCircle size={15} className="text-rose-500" /> Absent
              </span>
              <span className="text-sm font-semibold text-slate-800">
                {summary?.todayAttendance?.absent ?? 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm text-slate-600">
                <Clock size={15} className="text-amber-500" /> Leave
              </span>
              <span className="text-sm font-semibold text-slate-800">
                {summary?.todayAttendance?.leave ?? 0}
              </span>
            </div>
          </div>
        </div>

        <div className="card p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Fee Collection — {summary?.feeMonth}
            </p>
            <Wallet size={16} className="text-slate-300" />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <p className="text-xs text-slate-500">Collected</p>
              <p className="text-lg font-semibold text-emerald-600">
                {summary?.monthlyRevenue?.toLocaleString() ?? 0}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Payable</p>
              <p className="text-lg font-semibold text-slate-800">
                {summary?.monthlyPayable?.toLocaleString() ?? 0}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Pending</p>
              <p className="text-lg font-semibold text-rose-600">
                {summary?.pendingFees?.toLocaleString() ?? 0}
              </p>
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <span className="badge bg-emerald-50 text-emerald-700">
              Paid {summary?.feeStatus?.paid ?? 0}
            </span>
            <span className="badge bg-amber-50 text-amber-700">
              Partial {summary?.feeStatus?.partial ?? 0}
            </span>
            <span className="badge bg-rose-50 text-rose-700">
              Unpaid {summary?.feeStatus?.unpaid ?? 0}
            </span>
          </div>
        </div>
      </div>

      <div className="card mt-4 p-5">
        <p className="mb-4 text-xs font-semibold uppercase tracking-wide text-slate-500">
          Recent Admissions
        </p>
        {admissions.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">No admissions yet</p>
        ) : (
          <div className="space-y-3">
            {admissions.map((student) => (
              <div key={student._id} className="flex items-center justify-between border-b border-slate-50 pb-3 last:border-0 last:pb-0">
                <div>
                  <p className="text-sm font-medium text-slate-800">{student.name}</p>
                  <p className="text-xs text-slate-400">
                    {student.classId?.className || "-"} · {student.sectionName}
                  </p>
                </div>
                <span className="badge bg-slate-100 text-slate-600">{student.admissionNumber}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
