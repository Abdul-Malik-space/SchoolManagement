import { Receipt } from "lucide-react";
import { PageHeader } from "../../components/ui/PageHeader";

const FeeCollectionsList = () => (
  <div>
    <PageHeader title="Fee Collections" />
    <div className="card flex h-56 flex-col items-center justify-center gap-2 text-slate-400">
      <Receipt size={26} strokeWidth={1.5} />
      <p className="text-sm">This module is built next</p>
    </div>
  </div>
);

export default FeeCollectionsList;
