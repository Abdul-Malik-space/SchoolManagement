import { Routes, Route, Navigate } from "react-router-dom";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { DashboardLayout } from "./components/layout/DashboardLayout";

import Login from "./pages/auth/Login";
import Dashboard from "./pages/dashboard/Dashboard";

import SchoolsList from "./pages/schools/SchoolsList";
import SchoolDetail from "./pages/schools/SchoolDetail";

import UsersList from "./pages/users/UsersList";
import ClassesList from "./pages/classes/ClassesList";
import SubjectsList from "./pages/subjects/SubjectsList";
import TeachersList from "./pages/teachers/TeachersList";
import StudentsList from "./pages/students/StudentsList";
import AttendanceList from "./pages/attendance/AttendanceList";
import FeeStructuresList from "./pages/fee-structures/FeeStructuresList";
import FeeCollectionsList from "./pages/fee-collections/FeeCollectionsList";
import AuditLogsList from "./pages/audit-logs/AuditLogsList";

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route
        element={
          <ProtectedRoute roles={["super_admin"]}>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />

        <Route path="/schools" element={<SchoolsList />} />
        <Route path="/schools/:id" element={<SchoolDetail />} />

        <Route path="/users" element={<UsersList />} />
        <Route path="/classes" element={<ClassesList />} />
        <Route path="/subjects" element={<SubjectsList />} />
        <Route path="/teachers" element={<TeachersList />} />
        <Route path="/students" element={<StudentsList />} />
        <Route path="/attendance" element={<AttendanceList />} />
        <Route path="/fee-structures" element={<FeeStructuresList />} />
        <Route path="/fee-collections" element={<FeeCollectionsList />} />
        <Route path="/audit-logs" element={<AuditLogsList />} />
      </Route>

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default App;
